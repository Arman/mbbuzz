class LocationHints < Hobo::ViewHints


end
