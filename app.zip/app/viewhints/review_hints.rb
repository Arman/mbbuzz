class ReviewHints < Hobo::ViewHints


end
