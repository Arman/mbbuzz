class EmploymentHints < Hobo::ViewHints


end
