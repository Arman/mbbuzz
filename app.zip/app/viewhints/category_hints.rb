class CategoryHints < Hobo::ViewHints


end
