class MessageHints < Hobo::ViewHints


end
