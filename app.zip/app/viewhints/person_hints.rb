class PersonHints < Hobo::ViewHints


end
