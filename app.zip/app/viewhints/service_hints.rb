class ServiceHints < Hobo::ViewHints


end
