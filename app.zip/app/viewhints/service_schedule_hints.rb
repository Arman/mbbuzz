class ServiceScheduleHints < Hobo::ViewHints


end
