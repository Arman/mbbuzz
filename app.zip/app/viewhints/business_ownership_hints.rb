class BusinessOwnershipHints < Hobo::ViewHints


end
