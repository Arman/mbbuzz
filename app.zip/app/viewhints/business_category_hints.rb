class BusinessCategoryHints < Hobo::ViewHints


end
