class BusinessEmployeeHints < Hobo::ViewHints


end
