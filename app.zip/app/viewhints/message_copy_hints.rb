class MessageCopyHints < Hobo::ViewHints


end
