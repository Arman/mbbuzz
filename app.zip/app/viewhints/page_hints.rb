class PageHints < Hobo::ViewHints


end
