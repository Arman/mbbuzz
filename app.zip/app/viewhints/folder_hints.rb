class FolderHints < Hobo::ViewHints


end
