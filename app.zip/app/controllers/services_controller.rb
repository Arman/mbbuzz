class ServicesController < ApplicationController

  hobo_model_controller

  auto_actions :all

end
