class BusinessOwnershipsController < ApplicationController

  hobo_model_controller

  auto_actions :all #:lifecycle

end
