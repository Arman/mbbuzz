module FrontHelper
end
