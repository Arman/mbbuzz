module CategoriesHelper
end
